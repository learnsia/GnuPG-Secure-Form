/*******************/

Duane Dunston
thedunston@gmail.com


/*******************/

GnuPG Secure Form

These scripts were created to allow someone without GNUPG to send a message or documents securely to someone that does use GNUPG.
It has been very useful for me over the past several years. It is a web form that allows someone to send you an email and attachments.  The current attachment limit is set to two.  The sender can zip the file or send multiple email messages if required.  The connection to the form uses SSL and it encrypts the web form message and attachments and sends the receipient an encrypted email.

I have three versions.  One is just the standard script as described.  You can choose to allow certain people access to the scripts via .htaccess file or after authentication, or whatever works best for you.  Edit the config.php file and configure it with your particular settings.

You'll need to have GnuPG installed on the server running the scripts.

The other two are for fun.

/*********************   Recaptcha ***************************************/
One uses the recaptcha service before submitting the form, which is useful.  You'll need to create an account at recaptcha.net and download their PHP library API to use it with this script.

Setup: 

1. Download the recaptcha API tar file and extract it.
tar xzvf recaptcha-php-X.XX.zip

That will create the directory:  recaptcha-php-1.11/  Change it so that it is named:  recaptcha/

2. mv recaptcha-php-1.11/ recaptcha

3. This will work normally with the recaptcha version. Just be sure it is located in the same directory where the "index.php" and "sendattach.php" file is located or you'll need to edit the top of the "index.php" and "sendattach.php" files to point to the new location.

4. Edit the config.php file to update it with your particular settings and the public and private key provided when you register for a recaptcha.net account.

/***********************   End Recaptcha ****************************/

/********************  Two factor authentication ********************/

The other version uses two-factor authentication, which was more for fun after reading about phone authentication as a two-factor solution.

There is a mini admin script with it named "admin.php." You should move that file to a password protected directory where you can create accounts only after some form of authentication.  This script allows you to create a username, password, and the user's phone number, which is stored in an XML file using RIPEMD 160 for the password hash.

After the username and password are entered, it uses the free Phonefactor.com service service and API to call the user.  The free service only accepts a "#" as the authentication token.  After entering the "#," the user is then redirected to the secure web form.  Again, there is probably no practical need for the two-factor authentication for this script, but thought I'd include it.

For the Phone Factor authentication, you'll have to setup an account on their website: http://www.phonefactor.com

Edit the config.php file and configure it with your particular settings.

/********************  Two factor authentication ********************/
